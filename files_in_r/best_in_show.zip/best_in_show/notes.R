#------- Notes for Lecture on Files ------#

#------- The Working Directory ------#

# display the current working directory path

# set working directory in R

# set workign directory from RStudio


# Listing Files

# List Files given a path

#------- Reading and Writing Data ------#

# reading our csv

# inspect our data!

# saveRDS

# readRDS

### Reading in the Excel File?

#------- Using Packages  ------#

# CRAN
# https://cran.r-project.org/

# readxl
# https://cran.r-project.org/web/packages/readxl/index.html

# installing packages

# list installed packages

# loading packages

#-------  Reading Data from Excel ------#

# list sheets (excel_sheets())

# load data (read_xlsx())
