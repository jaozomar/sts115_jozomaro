Data from https://www.informationisbeautiful.net/visualizations/best-in-show-whats-the-top-data-dog/
Thanks Nick!
